package org.fkit.controller;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloController implements Controller {
    private static final Log log= LogFactory.getLog(HelloController.class);
    @Override
    public ModelAndView handleRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        log.info("handleRequest被调用");
        ModelAndView mv = new ModelAndView();
        mv.addObject("msg","helloWorld");
        mv.setViewName("/WEB-INF/content/welcome.jsp");
        return mv;
    }
}
