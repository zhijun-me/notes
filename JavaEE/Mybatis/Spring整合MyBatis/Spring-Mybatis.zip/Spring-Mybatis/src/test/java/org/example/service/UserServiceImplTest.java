package org.example.service;

import org.example.pojo.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring-mybatis.xml"})
public class UserServiceImplTest {

    @Autowired
    private UserService userService;

    @Test
    public void getUserByUsername() {
        User user = userService.getUserByUsername("ggg");
        System.out.println(user.getUsername());
        System.out.println(user.getPassword());
    }

    @Test
    public  void testSeleteAll(){
        List<User> userList = userService.selectAll();
        userList.forEach(System.out::println);
    }
}