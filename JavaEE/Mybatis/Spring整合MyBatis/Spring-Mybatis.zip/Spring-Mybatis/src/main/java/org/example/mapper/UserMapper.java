package org.example.mapper;

import org.apache.ibatis.annotations.Select;
import org.example.pojo.User;

import java.util.List;

public interface UserMapper {

    @Select("select * from user where username = #{username}")
    User selectUser1(String username);

    List<User>  selectAll();
}
