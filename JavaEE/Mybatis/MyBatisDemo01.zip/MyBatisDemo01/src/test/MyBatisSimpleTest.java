package test;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import domain.User;

public class MyBatisSimpleTest {

	public static void main(String[] args) throws Exception {
		// 读取 mybatis-config.xml配置文件
		InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
		// 初始化Mybatis,创建 SqlSessionFactory类的实例
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		SqlSession session = sqlSessionFactory.openSession();
		User user = new User("admin", "男", 26);
		// 插入数据
		session.insert("mapper.UserMapper.save", user);

		// 提交事务
		session.commit();
		// 关闭session
		session.close();

	}
}
