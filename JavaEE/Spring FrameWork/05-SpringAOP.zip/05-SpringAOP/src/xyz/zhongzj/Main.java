package xyz.zhongzj;

public class Main {

    public static void main(String[] args) {
	// write your code here
        System.out.println(1);
    }
}
