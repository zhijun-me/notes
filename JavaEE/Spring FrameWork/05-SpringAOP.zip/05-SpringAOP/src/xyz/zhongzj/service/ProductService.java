package xyz.zhongzj.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 目标类 target
 */
public class ProductService {
    private Log log = LogFactory.getLog(ProductService.class);

    /**
     * 连接点 ： target里面的所有可以被增强的方法，可能都会被Spring拦截，也可能只有一个
     *  add、update、delete
     */

    public void add() {
        log.info("添加商品");
    }
    public void update(){
        log.info("更新商品");
    }
    public void delete(){
        log.info("删除商品");
    }
}
