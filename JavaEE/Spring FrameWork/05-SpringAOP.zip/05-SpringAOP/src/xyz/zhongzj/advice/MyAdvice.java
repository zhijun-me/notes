package xyz.zhongzj.advice;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 通知（增强）
 */
public class MyAdvice {
    private Log log = LogFactory.getLog(MyAdvice.class);

    public void before() {

        log.info("before()");
    }

    public void after() {
        log.info("after()");
    }
}
