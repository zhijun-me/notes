package xyz.zhongzj;

import org.junit.Before;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import xyz.zhongzj.service.ProductService;
import org.junit.Test;

public class TestAop {

    private ApplicationContext context;

    @Before
    public void init() {
        context = new ClassPathXmlApplicationContext("applicationContext.xml");
    }
    @Test
    public void test2(){
        ProductService productService =context.getBean("productService",ProductService.class);
        productService.add();
    }

}
