package com.company.test;

import com.company.domain.User;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestSpring {
    private static final String CONFIG_FILE = "applicationContext.xml";

    @Test
    public void test1() {
        ApplicationContext context = new ClassPathXmlApplicationContext(CONFIG_FILE);
        User user = (User) context.getBean("user");
        System.out.println(user);
    }
}
